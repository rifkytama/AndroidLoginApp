// import StarIcon from '../../assets/Star.svg';

// function WidgetStar() {
//     return (
//         <div className="row">

//         </div>
//     );
// }

// export default WidgetStar
