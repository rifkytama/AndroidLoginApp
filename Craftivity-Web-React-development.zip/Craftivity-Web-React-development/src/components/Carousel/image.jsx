const images = [
  {
    id: 1,
    src: 'https://www.disability-grants.org/images/craft-time.jpg',
    alt: 'Image 1'
  },
  {
    id: 2,
    src: 'https://i0.wp.com/images-prod.healthline.com/hlcmsresource/images/topic_centers/depression/1296x728_HEADER_How-crafting-can-help-depression.jpg?w=1155&h=1528',
    alt: 'Image 2'
  },
  {
    id: 3,
    src: 'https://st.depositphotos.com/1000604/2118/i/600/depositphotos_21188543-stock-photo-scrap-details.jpg',
    alt: 'Image 3'
  }
]
export default images
