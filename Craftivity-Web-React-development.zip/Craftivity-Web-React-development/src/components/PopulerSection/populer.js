const populer = [
  {
    id: 1,
    src: 'https://www.disability-grants.org/images/craft-time.jpg',
    harga: 20000,
    star: 4,
    name: 'Image 1',
    terjual: 128,
    deskripsi: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam nec velit nec diam facilisis cursus. Quisque pellentesque lobortis lorem ac eleifend. Duis erat ligula, mollis eget laoreet id, aliquet a mi. Curabitur vitae posuere felis, non rhoncus purus. Sed ullamcorper enim orci, sit amet posuere dui commodo vitae. Nullam vitae porttitor dui. Integer vel placerat nisl. Fusce vitae tincidunt purus. Integer sit amet tellus vestibulum, vestibulum libero vitae, tristique neque. Pellentesque consequat sed mauris et scelerisque. Pellentesque sit amet volutpat lectus, eget dapibus ipsum. Aenean eu euismod mi. Donec dapibus ultrices rhoncus. Sed sodales dignissim orci vel accumsan. Morbi eget purus accumsan lorem efficitur viverra',
    toko: {
      image: 'https://stylesatlife.com/wp-content/uploads/2018/04/handmade-art-and-craft.jpg',
      name: 'TOKO KREATIF INDAH',
      location: 'Kab. Banyuasin'
    },
    review: [
      {
        name: 'Muana Excel',
        star: 4,
        image: 'https://www.amesbostonhotel.com/wp-content/uploads/2021/05/Teknik-Close-Up.jpg',
        review: "orem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum."
      },
      {
        name: 'Muana Excel',
        star: 4,
        image: 'https://www.amesbostonhotel.com/wp-content/uploads/2021/05/Teknik-Close-Up.jpg',
        review: "orem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum."
      }
    ]
  },
  {
    id: 2,
    src: 'https://i0.wp.com/images-prod.healthline.com/hlcmsresource/images/topic_centers/depression/1296x728_HEADER_How-crafting-can-help-depression.jpg?w=1155&h=1528',
    harga: 20000,
    star: 3,
    name: 'Image 2 '
  },
  {
    id: 3,
    src: 'https://st.depositphotos.com/1000604/2118/i/600/depositphotos_21188543-stock-photo-scrap-details.jpg',
    harga: 20000,
    star: 4,
    name: 'Image 3'
  },
  {
    id: 3,
    src: 'https://st.depositphotos.com/1000604/2118/i/600/depositphotos_21188543-stock-photo-scrap-details.jpg',
    harga: 20000,
    star: 5,
    name: 'Image 3'
  },
  {
    id: 3,
    src: 'https://st.depositphotos.com/1000604/2118/i/600/depositphotos_21188543-stock-photo-scrap-details.jpg',
    harga: 20000,
    star: 5,
    name: 'Image 3'
  }
]
export default populer
