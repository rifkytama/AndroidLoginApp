import React from 'react'
import './listBarang.css'

export default function Index () {
  return (
    <div>index</div>
  )
}
