const keranjang = [
  {
    id: 1,
    name: 'Lorem Ipsum',
    image: 'https://dikemas.com/uploads/2022/04/Banana-Juara_Duo-Kuning_Logoo-720x432.jpg',
    harga: 20000,
    toko: {
      name: 'Toko Bumi Pertiwi'
    }
  },
  {
    id: 1,
    name: 'Lorem Ipsum',
    image: 'https://dikemas.com/uploads/2022/04/Banana-Juara_Duo-Kuning_Logoo-720x432.jpg',
    harga: 20000,
    toko: {
      name: 'Toko Bumi Pertiwi'
    }
  },
  {
    id: 1,
    name: 'Lorem Ipsum',
    image: 'https://dikemas.com/uploads/2022/04/Banana-Juara_Duo-Kuning_Logoo-720x432.jpg',
    harga: 20000,
    toko: {
      name: 'Toko Bumi Pertiwi'
    }
  }
]

export default keranjang
