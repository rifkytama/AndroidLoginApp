const CONFIQ = {
  authMitra: 'AUTH_MITRA',
  authUser: 'AUTH_USER'
}

export default CONFIQ
